﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using BruTile;
using BruTile.Cache;
using BruTile.Predefined;
using BruTile.Web;
using BrutileArcGIS.Lib;
using BrutileArcGIS.lib;
using ESRI.ArcGIS.Geometry;

namespace ConsoleApplication8
{


    namespace DownloadTiles
    {
        class DownloadTask
        {
            private static ITileSource _tileSource;
            private static FileCache _fileCache;
            private string _cacheDir;
            List<TileInfo> _tiles;
            static WebTileProvider _tileProvider;
            private List<double> extent;

            private string _extent = "-14734.9298441096,6711290.4995964,-13505.3438390165,6712196.510337";
            //private string _extent = "-0.131715,51.506440,-0.123204,51.510442";


            public void DoMainTask()
            {
                extent = _extent.Split(new[] { ',' }).Select(Convert.ToDouble).ToList();

                IConfig _config = new Config();
                _tileSource = _config.CreateTileSource();
                _tileProvider = (WebTileProvider)_tileSource.Provider;
                _cacheDir = @"D:\我的程序\开源项目\Here3D\model";
                _fileCache = CacheDirectory.GetFileCache(_cacheDir, _config, EnumBruTileLayer.OSM);
                _tiles = GetTile();

                Draw();
            }

            public void Draw()
            {
                _tiles = GetTile();


                if (_tiles.Count > 0)
                {
                    foreach (var info in _tiles)
                    {
                        DownloadTile(info);
                        Thread.Sleep(1000);
                    }
                }
                //if (_tiles.Any())
                //{
                //    var downloadFinished = new ManualResetEvent(false);
                //    var t = new Thread(DownloadTiles);
                //    t.Start(downloadFinished);
                //    downloadFinished.WaitOne();
                //}
            }


            private void DownloadTiles(object args)
            {
                var downloadFinished = args as ManualResetEvent;

                // Loop through the tiles, and filter tiles that are already on disk.
                var downloadTiles = new List<TileInfo>();
                for (var i = 0; i < _tiles.Count(); i++)
                {

                        downloadTiles.Add(_tiles[i]);
                  
                }

                if (downloadTiles.Count > 0)
                {
                    foreach (var info in downloadTiles)
                    {
                        DownloadTile(info);
                    }
                    //int count = 1;
                    //int allCount = 1;
                    //while ((count - 1) * allCount < downloadTiles.Count)
                    //{
                    //    int temp = allCount;
                    //    if (count * allCount > downloadTiles.Count)
                    //        temp = downloadTiles.Count - (count - 1) * allCount;
                    //    var doneEvents = new MultipleThreadResetEvent(temp);
                    //    for (int i = 0; i < temp; i++)
                    //    {
                    //        TileInfo t = downloadTiles[(count - 1) * allCount + i];
                    //        object o = new object[] { t, doneEvents };
                    //        ThreadPool.SetMaxThreads(1, 1);
                    //        ThreadPool.QueueUserWorkItem(DownloadTile, o);
                    //    }
                    //    doneEvents.WaitAll();
                    //    doneEvents.Dispose();
                    //    //Thread.Sleep(10);
                    //    count++;
                    //}
                }

                if (downloadFinished != null) downloadFinished.Set();
            }

            private void DownloadTile(TileInfo tileInfo)
            {
                var url = _tileProvider.Request.GetUri(tileInfo);

                DownloadFile(tileInfo);

                var bytes = GetBitmap(url);

                try
                {
                    if (bytes != null)
                    {
                        var name = _fileCache.GetFileName(tileInfo.Index);
                        _fileCache.Add(tileInfo.Index, bytes);
                        CreateRaster(tileInfo, name);

                    }
                }
                catch (Exception ex)
                {

                }

            }

            private void DownloadTile(object tile)
            {
                var parameters = (object[])tile;
                if (parameters.Length != 2) throw new ArgumentException("Two parameters expected");
                var tileInfo = (TileInfo)parameters[0];
                var doneEvent = (MultipleThreadResetEvent)parameters[1];

                var url = _tileProvider.Request.GetUri(tileInfo);

                DownloadFile(tileInfo);

                var bytes = GetBitmap(url);

                try
                {
                    if (bytes != null)
                    {
                        var name = _fileCache.GetFileName(tileInfo.Index);
                        _fileCache.Add(tileInfo.Index, bytes);
                        CreateRaster(tileInfo, name);

                    }
                }
                catch (Exception ex)
                {

                }
                doneEvent.SetOne();
            }

            public void DownloadFile(TileInfo tileInfo)
            {
                var index = tileInfo.Index;
                int zoom = int.Parse(index.Level);
                int col = index.Col;
                int row = (int)(Math.Pow(2, zoom) - index.Row) - 1;

                int deltaZoom = zoom - 13;
                int x13 = index.Col/(1 << deltaZoom);
                int y13 = index.Row/(1 << deltaZoom);
                int col13 = x13;
                int row13 = (int)(Math.Pow(2, 13) - y13) - 1;
                string urllut = "http://b.maps3d.svc.nokia.com/data4//" + GetUrl(13, row13, col13) + ".lut";
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(urllut);
                request.Method = "GET";
                MemoryStream ms = new MemoryStream();
                WebResponse response = request.GetResponse();
                response.GetResponseStream().CopyTo(ms);
                byte[] data = ms.ToArray();
                int off = 0;
                for (int i = 0; i < deltaZoom; i++)
                {
                    off += (int)Math.Pow(4, i);
                }

                int xzoom = x13*(1 << deltaZoom);
                int yzoom = y13*(1 << deltaZoom);
                off += (index.Col - xzoom) * (1<<deltaZoom);
                off += (1 << deltaZoom) - (index.Row - yzoom) -1;
                int bottom = BitConverter.ToInt16(data, off*4);
                int top = BitConverter.ToInt16(data, off*4 + 2);


                string url = "http://b.maps3d.svc.nokia.com/data4//" +GetUrl( zoom, row, col) + ".n3m";
                var name = _fileCache.GetFileName(tileInfo.Index);
                FileInfo fileinfo = new FileInfo(name);
                string filename = fileinfo.DirectoryName + "/map_" + zoom +"_" + row + "_" + col + ".n3m";
                try
                {
                    var scale = (tileInfo.Extent.MaxX - tileInfo.Extent.MinX) / _tileSource.Schema.GetTileWidth("0");
                    var lng = tileInfo.Extent.MinX;
                    var lat = tileInfo.Extent.MaxY;

                    WebClient webClient = new WebClient();
                    webClient.DownloadFile(url, filename);
                    ProcessStartInfo startInfo = new ProcessStartInfo(@"C:\Users\Administrator\Documents\Visual Studio 2010\Projects\n3mtodae\Debug\n3mtodae.exe");
                    startInfo.Arguments = filename + " " + filename.Replace(".n3m", ".dae") + " " + fileinfo.DirectoryName+"\\" + " "+lng+" "+lat+" "+scale+" "+bottom+" "+top;
                    startInfo.CreateNoWindow = true;
                    Process.Start(startInfo);
                }
                catch (Exception)
                {
                    
                }

            }

            public string GetUrl(int zoom,int row,int col)
            {
                int len = (int)(Math.Floor(Math.Log(2) / Math.Log(10) * zoom)) + 1;
                string format = "";
                for (int i = 0; i < len; i++)
                {
                    format += "0";
                }
                string rows = row.ToString(format);
                string cols = col.ToString(format);
                string dir = "";
                if (len == 4)
                    dir = rows.Substring(0, 2) + cols.ToString().Substring(0, 2) + "/" +
                          rows.Substring(2, 1) + cols.ToString().Substring(2, 1);
                else if (len == 5)
                    dir = rows.Substring(0, 2) + cols.ToString().Substring(0, 2) + "/" +
  rows.Substring(2, 2) + cols.ToString().Substring(2, 2);
                else
                    dir = rows.Substring(0, 2) + cols.ToString().Substring(0, 2) + "/" +
rows.Substring(2, 2) + cols.ToString().Substring(2, 2) + "/" + rows.Substring(4, 1) + cols.ToString().Substring(4, 1);

                return zoom.ToString() + "/" + dir + "/map_" + zoom +
                       "_" + row + "_" + col;
            }

            public byte[] GetBitmap(Uri uri)
            {
                byte[] bytes = null;

                int count = 1;
                while (true)
                {
                    try
                    {
                        bytes = RequestHelper.FetchImage(uri);
                        break;
                    }
                    catch (System.Net.WebException ex)
                    {
                        count++;
                        if (count > 10)
                            break;
                    }
                }

                return bytes;
            }

            private void CreateRaster(TileInfo tile, string name)
            {
                var schema = _tileSource.Schema;
                var fi = new FileInfo(name);
                var tfwFile = name.Replace(fi.Extension, "." + WorldFileWriter.GetWorldFile(schema.Format));
                WorldFileWriter.WriteWorldFile(tfwFile, tile.Extent, schema);
            }


            private List<TileInfo> GetTile()
            {
                Extent exten = new Extent(extent[0], extent[1], extent[2], extent[3]);
                int level1 = 17;
                List<TileInfo> alltiles = new List<TileInfo>();
                var tiles = _tileSource.Schema.GetTilesInView(exten, level1.ToString());

                if (tiles.Any())
                    alltiles.AddRange(tiles);
                return alltiles;
            }

            //private List<TileInfo> GetTile()
            //{
            //    var schema = _tileSource.Schema;
            //    IEnvelope pEnvelope = new EnvelopeClass();
            //    ISpatialReferenceFactory pSpatRefFact = new SpatialReferenceEnvironmentClass();
            //    pEnvelope.SpatialReference = pSpatRefFact.CreateGeographicCoordinateSystem(4326);
            //    pEnvelope.XMin = extent[0];
            //    pEnvelope.XMax = extent[2];
            //    pEnvelope.YMin = extent[1];
            //    pEnvelope.YMax = extent[3];


            //    var env = Projector.ProjectEnvelope(pEnvelope, schema.Srs);

            //    var mapWidth = 256 * num;
            //    var mapHeight = 256 * num;
            //    float resolution = (float)level;


            //    var centerPoint = env.GetCenterPoint();

            //    var transform = new Transform(centerPoint, resolution, mapWidth, mapHeight);
            //    var level1 = Utilities.GetNearestLevel(schema.Resolutions, transform.Resolution);

            //    var tiles = schema.GetTilesInView(transform.Extent, level1);

            //    return tiles.ToList();
            //}
        }
    }

}
public class Config : IConfig
{

    public ITileSource CreateTileSource()
    {
        return new HttpTileSource(new GlobalSphericalMercator(0, 20),
            "http://{s}.maps.nlp.nokia.com.cn/maptile/2.1/maptile/5b33fc2110/hybrid.day/{z}/{x}/{y}/256/png8?lg=CHI&app_id=90oGXsXHT8IRMSt5D79X&token=JY0BReev8ax1gIrHZZoqIg&xnlp=CL_JSMv2.5.3.2",
            //"http://webst0{s}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}",
                   new[] { "1", "2", "3", "4" }, name: "HereMap");
    }
}
