﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using BruTile;
using BruTile.Predefined;
using BruTile.Web;
using ConsoleApplication8.DownloadTiles;
using ESRI.ArcGIS;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {

            RuntimeManager.BindLicense(ProductCode.EngineOrDesktop);
            DownloadTask  download = new DownloadTask();
            download.DoMainTask();
        }

        public static byte[] FileToStream(string fileName)
        {
            // 打开文件 
            FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            // 读取文件的 byte[] 
            byte[] bytes = new byte[fileStream.Length];
            fileStream.Read(bytes, 0, bytes.Length);
            fileStream.Close();
            return bytes;
        }
    }
}
